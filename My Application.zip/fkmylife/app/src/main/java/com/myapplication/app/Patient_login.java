package com.myapplication.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Patient_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_login);
    }
}